import logo from './logo.svg';
import './App.css';
import Home from './containers/Home'
function App() {
  return (
    <>
      <Home/>
    </>
  );
}

export default App;
