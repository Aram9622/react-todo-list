import { useEffect, useState } from "react"
import TodoList from "../components/todoList/TodoList";
import Pagination from "react-js-pagination";
import Archive from "../components/archive/Archive";
import './style.css'
export default function Home() {
    let [todo, setTodo] = useState({
        id: Date.now(),
        title: '',
        isComplete: false
    })

    let [archiveData, setArchiveData] = useState([])
    let [data, setData] = useState(window.localStorage.getItem(`data`) ? JSON.parse(window.localStorage.getItem(`data`)) : []);
    let [activepage, setActivePage] = useState({
        activePage: window.localStorage.getItem(`page`) ? window.localStorage.getItem(`page`) : 1,
    })
    let [filter, setFilter] = useState(1)
    function addTodoState(e) {
        setTodo({
            ...todo,
            id: Date.now(),
            title: e.target.value
        })
    }

    let addTodo = async (item) => {
        
        if(!todo.title == ''){
            setData([
                ...data,
                todo
            ]);
             setTodo({
                ...todo,
                title: ''
            });
            await new Promise(res=>{
                res([...data, todo])
            }).then(res=>{
                window.localStorage.setItem('data', JSON.stringify(res));
            })
            document.querySelector('input').style.border='2px solid #e5e5e5';
        }
        else{
            document.querySelector('input').style.border='2px solid red';
        }
        
    }

    function removeitem(id) {
        console.log(id, `IDDDDDDDDD`);
        let dataLocal = JSON.parse(window.localStorage.getItem('data'))
        let filterData = dataLocal.filter((item, index) => { return index !== id });
        setData(filterData)
        window.localStorage.setItem(`data`, JSON.stringify(filterData))
    }

    function CheckIsComplete(e) {
        console.log(e);
        setData(
            data.map(item => {
                if (item.id === e) {
                    item.isComplete = !item.isComplete
                }
                return item
            })
        )
    }

    function handlePageChange(pageNumber) {
        setActivePage({ activePage: pageNumber });
        window.localStorage.setItem('page', pageNumber);
    }

    function filterItem(e) {
        setFilter(Number(e.target.value))
    }

    function archivitem(id) {
        setArchiveData([
            ...archiveData,
            data[id]
        ]);
        setData(data.filter((item, index) => { return index !== id }))
    }

    function activeitem(id) {
        console.log(id, 'IDDDDDDDDDDDDDDDDDDDD')
        setData([
            ...data,
            archiveData[id]
        ])
        setArchiveData(archiveData.filter((item, index) => { return index !== id }))
    }
    console.log(window.localStorage.getItem('page'),)
    return (
        <>
            <div className="form-todo">
                <h3>Title</h3>
                <input type="text" name='title' onChange={addTodoState} value={todo.title} />
                <select name="" id="" onChange={filterItem}>
                    <option value="1">1</option>
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="30">30</option>
                </select>
                <p></p>
                <button onClick={() => addTodo(todo)} className='addbutton'>Add</button>
                <TodoList todo={data} remove={removeitem} complete={CheckIsComplete} page={activepage.activePage} itemCount={5} archiveItem={archivitem} />
                <Pagination
                    activePage={ activepage.activePage}
                    itemsCountPerPage={5}
                    totalItemsCount={data.length}
                    pageRangeDisplayed={5}
                    onChange={handlePageChange}
                    hideNavigation={false}
                />

                {archiveData.length > 0 ? <Archive data={archiveData} activeItem={activeitem} className='archive' /> : null}
            </div>


        </>
    )
}